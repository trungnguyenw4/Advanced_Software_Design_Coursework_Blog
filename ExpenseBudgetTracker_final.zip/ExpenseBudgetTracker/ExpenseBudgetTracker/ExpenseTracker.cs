﻿using System;
using System.Linq;
using Newtonsoft.Json.Linq;

namespace ExpenseBudgetTracker
{
    public class ExpenseTracker
    {

        private List<Transaction> transactions;
        private List<Category> categories;
        private Budget budget;
        private DataController DataController;

        public ExpenseTracker(string transactionFilePath)
        {
            transactions = new List<Transaction>();
            categories = new List<Category>();
            budget = new Budget();
            DataController = new DataController(transactionFilePath);

            LoadTransactions();
            LoadCategories();
        }

        public static decimal GetDecimalInput(string prompt)
        {
            decimal result;
            bool validInput = false;
            do
            {
                Console.Write(prompt);
                validInput = decimal.TryParse(Console.ReadLine(), out result);
                if (!validInput)
                {
                    Console.Clear();
                    Console.WriteLine("Please enter a valid value. ");
                }
            } while (!validInput);

            return result;
        }


        public static int GetIntInput(string prompt)
        {
            int result;
            bool validInput = false;
            do
            {
                Console.Write(prompt);
                validInput = int.TryParse(Console.ReadLine(), out result);
                if (!validInput)
                {
                    Console.Clear();
                    Console.WriteLine("Invalid input. Please enter a valid integer. ");
                }
            } while (!validInput);

            return result;
        }


        public static bool GetBoolInput(string prompt)
        {
            bool result;
            bool validInput = false;
            do
            {
                Console.Write(prompt);
                validInput = bool.TryParse(Console.ReadLine(), out result);
                if (!validInput)
                {
                    Console.Clear();
                    Console.WriteLine("Invalid input. Please enter a valid bool. ");
                }
            } while (!validInput);

            return result;
        }

        public static string GetStringInput(string prompt)
        {

            Console.Write(prompt);
            string value = Console.ReadLine().ToUpper();

            while (string.IsNullOrWhiteSpace(value))
            {
                Console.Clear();
                Console.Write(prompt);
                value = Console.ReadLine();
            }
            return value;
        }

        public static DateOnly GetDateInput(string prompt)
        {
            DateOnly result;
            bool validInput = false;
            do
            {
                Console.Write(prompt);
                validInput = DateOnly.TryParse(Console.ReadLine(), out result);
                if (!validInput)
                {
                    Console.Clear();
                    Console.WriteLine("Invalid input.Please enter a valid DateOnly value (YYYY,MM,DD).");
                }
            } while (!validInput);

            return result;
        }



        public void LoadCategories()
        {
            categories = DataController.LoadCategories();
        }

        public void LoadTransactions()
        {
            
            DataController.LoadTransactions(transactions, budget);
        }

        public void SaveTransactions()
        {
           
            DataController.SaveTransactions(transactions, budget);
        }

        public void AddTransaction(decimal amount, TransactionType type, string category, string note, bool isRecurring, DateOnly date)
        {
            Transaction transaction;
            if (type == TransactionType.Expense)
            {
                transaction = new Expense(amount, category, note, isRecurring, date);
            }
            else
            {
                transaction = new Income( amount, category, note, isRecurring, date);
            }

            transactions.Add(transaction);
            categories.Add(new Category(category));
            SaveTransactions();
        }



        public void AddExpense()
        {
            
            decimal amount = GetDecimalInput("Enter amount: ");

            DateOnly date = GetDateInput("Enter date: ");

            string category = GetStringInput("Enter category: ");

            Console.Write("Enter note: ");
            string note = Console.ReadLine();

            bool isRecurring = GetBoolInput("Is it recurring? (true/false): ");

            AddTransaction(amount, TransactionType.Expense, category, note, isRecurring, date);
            Console.WriteLine("Expense added successfully.");
        }


        public void AddIncome()
        {
            decimal amount = GetDecimalInput("Enter amount: ");

            DateOnly date = GetDateInput("Enter date: ");

            string category = GetStringInput("Enter category: ");

            Console.Write("Enter note: ");
            string note = Console.ReadLine();

            bool isRecurring = GetBoolInput("Is it recurring? (true/false): ");

            AddTransaction(amount, TransactionType.Income, category, note, isRecurring, date);
            Console.WriteLine("Income added successfully.");
        }

     
        public void EditTransaction()
        {

            int index = GetIntInput("Enter the index of transaction to edit: ");



            if (index >= 0 && index < transactions.Count)
            {

                decimal newAmount = GetDecimalInput("Enter new amount: ");

                DateOnly newDate = GetDateInput("Enter new date: ");

                string newCategory = GetStringInput("Enter new category: ");


                Console.Write("Enter new note: ");
                string newNote = Console.ReadLine();

                bool newIsRecurring = GetBoolInput("Is it recurring? (true/false): ");

                Transaction editedTransaction = transactions[index];
                editedTransaction.Amount = newAmount;
                editedTransaction.Date = newDate;
                editedTransaction.Category = newCategory;
                editedTransaction.Note = newNote;
                editedTransaction.IsRecurring = newIsRecurring;

                SaveTransactions();
                Console.WriteLine("Transaction edited successfully.");
            }
            else
            {
                Console.WriteLine("Invalid index for editing transaction.");
            }

           
        }

        public void DeleteTransaction()
        {

            Console.Write("Enter the index of transaction to delete: ");
            int index = int.Parse(Console.ReadLine());

            if (index >= 0 && index < transactions.Count)
            {
                transactions.RemoveAt(index);
                SaveTransactions();
                Console.WriteLine("Transaction deleted successfully.");
            }
            else
            {
                Console.WriteLine("Invalid index for deleting transaction.");
            }

            
        }

        public void DisplayRecentTransactions()
        {
           

            foreach (var transaction in transactions)
            {
                Console.WriteLine(transactions.IndexOf(transaction)+ "__" + transaction.ToString());
            }

           
        }

        public void DisplayCategories()
        {

            Console.WriteLine("Available Categories:");
            foreach (var category in categories)
            {
                Console.WriteLine(category.Name);
            }
            
        }

        public void SetBudget()
        {
            Console.WriteLine("Budget for Categories:");
            foreach (var kvp in budget.CategoryBudgets)
            {
                Console.WriteLine($"{kvp.Key}: {kvp.Value}");
            }


            List<String> existedCategories = new List<String>();
            foreach (var categoryName in categories)
            {
                existedCategories.Add(categoryName.Name);
            }


            string category = GetStringInput("Enter category to set budget for: ");
            

            if (!existedCategories.Contains(category))
                {
                categories.Add(new Category(category));
                existedCategories.Add(category);
                }

            decimal amount = GetDecimalInput("Enter budget amount: ");
            budget.SetBudget(category, amount);
            Console.WriteLine("Budget set successfully.");

        }


        public void EditBudget()
        {
            string category = GetStringInput("Enter category to edit budget: ");
           
            bool found = false;



            foreach (var kvp in budget.CategoryBudgets)
                {
                if (kvp.Key == category)

                {
                    decimal newAmount = GetDecimalInput("Enter new budget for " + category + " :");
                   
                    budget.SetBudget(category, newAmount);
                    
                    Console.WriteLine("Budget changed successfully.");
                    found = true;
                    break;

                }

                }

                 if (!found)
                {
                    Console.WriteLine("Invalid Category for editing.");

                }





        }

        public void DisplayBudget()
        {
            

            Console.WriteLine("Budget for Categories:");
            foreach (var kvp in budget.CategoryBudgets)
            {
                Console.WriteLine($"{kvp.Key}: {kvp.Value}");
            }

           
        }

        public void TrackProgress()
        {

            decimal overallBudget = 0;


            Console.WriteLine("Budget vs Spending:");

            foreach (var kvp in budget.CategoryBudgets)
            {
                decimal spending = transactions
                    .Where(t => t.Category == kvp.Key && t.Type == TransactionType.Expense)
                    .Sum(t => t.Amount);

                overallBudget += kvp.Value; 

                Console.WriteLine($"{kvp.Key}: Spent {spending}, Budget {kvp.Value}");
            }

            decimal overallSpending = transactions
                .Where(t => t.Type == TransactionType.Expense)
                .Sum(t => t.Amount);


            Console.WriteLine($"Overall Spending: {overallSpending} -- Overall Budget: {overallBudget}"  );

         
        }

        public void TrackSpendingByCategory()
        {

            Console.WriteLine("Spending by Category:");
            foreach (var category in categories)
            {
                decimal spending = transactions
                    .Where(t => t.Category == category.Name && t.Type == TransactionType.Expense)
                    .Sum(t => t.Amount);

                Console.WriteLine($"{category.Name}: Spent {spending}");
            }

         
        }
    }
}

