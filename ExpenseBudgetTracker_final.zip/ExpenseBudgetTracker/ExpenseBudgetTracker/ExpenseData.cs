﻿using System;
namespace ExpenseBudgetTracker
{
	public class ExpenseData
	{
		public ExpenseData()
		{
		}
	}
}

