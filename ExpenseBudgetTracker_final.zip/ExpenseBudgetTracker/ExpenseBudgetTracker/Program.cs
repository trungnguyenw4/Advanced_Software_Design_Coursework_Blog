﻿using System.Text.Json;

namespace ExpenseBudgetTracker;

class Program
{
    
    static void ShowMenu()
    {

        Console.WriteLine("Expense Tracker Menu:");
        Console.WriteLine("1. Add Expense");
        Console.WriteLine("2. Add Income");
        Console.WriteLine("3. Edit Transaction");
        Console.WriteLine("4. Delete Transaction");
        Console.WriteLine("5. Display Recent Transactions");
        Console.WriteLine("6. Display Categories");
        Console.WriteLine("7. Set Budget");        
        Console.WriteLine("8. Display Budget");
        Console.WriteLine("9. Edit Budget");
        Console.WriteLine("10. Track Progress");
        Console.WriteLine("11. Track Spending by Category");
        Console.WriteLine("12. Save and Exit");


     
    }


    static void Main()
    {
        

        ExpenseTracker expenseTracker = new ExpenseTracker("transactions.txt");

        bool showingMenu = true;

        while (showingMenu)
        {
            Console.Clear();
            ShowMenu();
            Console.Write("Enter your choice (1-11): ");
            

            switch (Console.ReadLine())
            {
                case "1":
                    Console.Clear();
                    expenseTracker.AddExpense();
                    Console.WriteLine("Press any key to come back to the previous menu.");
                    Console.ReadKey();
                    break;
                case "2":
                    Console.Clear();
                    expenseTracker.AddIncome();
                    Console.WriteLine("Press any key to come back to the previous menu.");
                    Console.ReadKey();

                    break;
                case "3":
                    Console.Clear();
                    expenseTracker.EditTransaction();
                    Console.WriteLine("Press any key to come back to the previous menu.");
                    Console.ReadKey();
                    break;
                case "4":
                    Console.Clear();
                    expenseTracker.DeleteTransaction();
                    Console.WriteLine("Press any key to come back to the previous menu.");
                    Console.ReadKey();
                    break;
                case "5":
                    Console.Clear();
                    expenseTracker.DisplayRecentTransactions();
                    Console.WriteLine("Press any key to come back to the previous menu.");
                    Console.ReadKey();
                    break;
                case "6":
                    Console.Clear();
                    expenseTracker.DisplayCategories();
                    Console.WriteLine("Press any key to come back to the previous menu.");
                    Console.ReadKey();
                    break;
                case "7":
                    Console.Clear();
                    expenseTracker.SetBudget();
                    Console.WriteLine("Press any key to come back to the previous menu.");
                    Console.ReadKey();
                    break;
                case "8":
                    Console.Clear();
                    expenseTracker.DisplayBudget();
                    Console.WriteLine("Press any key to come back to the previous menu.");
                    Console.ReadKey();
                    break;
                case "9":
                    Console.Clear();
                    expenseTracker.EditBudget();
                    Console.WriteLine("Press any key to come back to the previous menu.");
                    Console.ReadKey();
                    break;
                case "10":
                    Console.Clear();
                    expenseTracker.TrackProgress();
                    Console.WriteLine("Press any key to come back to the previous menu.");
                    Console.ReadKey();
                    break;
                case "11":
                    Console.Clear();
                    expenseTracker.TrackSpendingByCategory();
                    Console.WriteLine("Press any key to come back to the previous menu.");
                    Console.ReadKey();
                    break;
                case "12":
                    // Save data before exiting
                    Console.Clear();
                    expenseTracker.SaveTransactions();
                    Console.WriteLine("Data saved. Exiting...");
                    showingMenu = false;
                    break;
                    
                default:
                    Console.WriteLine("Invalid choice. Try again.");
                    break;
            }
        }
        
    }

}

