﻿using System;
namespace ExpenseBudgetTracker
{
	public enum TransactionType
	{
        Expense,
        Income
    }
}

