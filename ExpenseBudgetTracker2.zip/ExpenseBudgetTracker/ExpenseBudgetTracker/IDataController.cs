﻿using System;
namespace ExpenseBudgetTracker
{
	public interface IDataController
	{
	}
}

