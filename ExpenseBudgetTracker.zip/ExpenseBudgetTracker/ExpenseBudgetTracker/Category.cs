﻿using System;
namespace ExpenseBudgetTracker
{
	public class Category
	{
        public string Name { get; set; }

        public Category(string name)
        {
            Name = name;
        }
    }
}

