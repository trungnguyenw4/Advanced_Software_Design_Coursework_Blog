﻿using System;
using System.IO;
using System.Xml;
using Newtonsoft.Json;

namespace ExpenseBudgetTracker
{
	public class DataController
    {
        private readonly string filePath;

        public DataController(string filePath)
        {
            this.filePath = filePath;
        }

        public void SaveTransactions(List<Transaction> transactions, Budget budget)
        {
            using (StreamWriter writer = new StreamWriter(filePath))
            {
                

                foreach (var transaction in transactions)
                {
                    writer.WriteLine($"{transaction.Amount},{transaction.Type},{transaction.Category},{transaction.Note},{transaction.IsRecurring},{transaction.Date}");
                }


                
                foreach (var kvp in budget.CategoryBudgets)
                {
                    writer.WriteLine($"{kvp.Key},{kvp.Value}");
                }
            }
        }

        
        public void LoadTransactions(List<Transaction> transactions, Budget budget)
        {
          
          

            if (File.Exists(filePath))
            {
                using (StreamReader reader = new StreamReader(filePath))
                {
                    

                    while (!reader.EndOfStream)
                    {
                        
                            string[] parts = reader.ReadLine().Split(',');

                        if (parts.Length == 2 )
                        {
                           
                            string category = parts[0];
                           
                            decimal budgetAmount = decimal.Parse(parts[1]);
                            budget.SetBudget(category, budgetAmount);

                        }

                        else {
                  

                            decimal amount = decimal.Parse(parts[0]);
                            TransactionType type = (TransactionType)Enum.Parse(typeof(TransactionType), parts[1]);
                            string category = parts[2];
                            string note = parts[3];
                            bool isRecurring = bool.Parse(parts[4]);

                            DateOnly date = DateOnly.Parse(parts[5]);

                            if (type == TransactionType.Expense)
                            {
                                transactions.Add(new Expense(amount, category, note, isRecurring, date));
                            }
                            else if (type == TransactionType.Income)
                            {
                                transactions.Add(new Income(amount, category, note, isRecurring, date));
                            }
                            

                        }
                    }
                }
            }
            
           
        }


        public List<Category> LoadCategories()
        {
           

            List<Category> categories = new List<Category>();
            
            if (File.Exists(filePath))
            {
                using (StreamReader reader = new StreamReader(filePath))
                {
                    
                    while (!reader.EndOfStream)
                    {
                        string[] parts = reader.ReadLine().Split(',');

                        if (parts.Length != 2)

                        { string category = parts[2];
                          categories.Add(new Category(category));
                        }
                    
                    }
                }
            }
           
            return categories;
        }


    }



}

