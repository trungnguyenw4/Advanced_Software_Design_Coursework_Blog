﻿using System;
namespace ExpenseBudgetTracker
{
	public class Income : Transaction
    {
       
        public Income( decimal amount, string category, string note, bool isRecurring, DateOnly date)
        : base( amount, TransactionType.Income, category, note, isRecurring, date)
        {
        }
 
    }
}

